const consol = document.getElementById("console");
const clearbtn = document.getElementById("clear");

function clear(){

        
         consol.innerHtml = "";
      


}